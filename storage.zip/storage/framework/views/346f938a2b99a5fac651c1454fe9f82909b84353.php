<?php $__env->startSection('content'); ?>
<div class="container">
    <h3>Dashboard Operator</h3>
    <p>Ubah status kehadiran pejabat dengan cepat.</p>

    <table class="table table-bordered table-striped">
        <thead class="thead-light" >
            <tr class="text-center">
                <th>Foto</th>
                <th>Nama</th>
                <th>Jabatan</th>
                <th>Kategori</th>
                <th>Status</th>
                <th style="min-width: 130px">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $icons = [
                    'Pimpinan'        => 'fa-user-tie',
                    'HakimTinggi'    => 'fa-scale-balanced',
                    'Kesekretariatan' => 'fa-folder-open',
                    'Kepaniteraan'    => 'fa-book',
                ];
                $icon = $icons[$emp->category] ?? 'fa-user';
            ?>
            <tr id="row-<?php echo e($emp->id); ?>">
                <td><?php if($emp->photo): ?><img src="/storage/<?php echo e($emp->photo); ?>" width="60"><?php endif; ?></td>
                <td><?php echo e($emp->name); ?></td>
                <td><?php echo e($emp->position); ?></td>
                <td><?php echo e($emp->category); ?></td>
                <td>
                    <span class="badge badge-<?php echo e($emp->status == 'ada' ? 'success' : 'danger'); ?>" id="status-<?php echo e($emp->id); ?>">
                        <?php echo e($emp->status == 'ada' ? 'ADA' : 'KELUAR'); ?>

                    </span>
                </td>
                <td>
                    <button class="btn btn-sm btn-success" onclick="updateStatus(<?php echo e($emp->id); ?>, 'ada')">Ada</button>
                    <button class="btn btn-sm btn-danger" onclick="updateStatus(<?php echo e($emp->id); ?>, 'tidak_ada')">Keluar</button>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
function updateStatus(id, status) {
    $.post("<?php echo e(route('status.update')); ?>", {
        _token: $('meta[name="csrf-token"]').attr('content'),
        employee_id: id,
        status: status
    }, function(res) {
        if (res.success) {
            const badge = $('#status-' + id);
            badge.removeClass('badge-success badge-danger')
                 .addClass(status === 'ada' ? 'badge-success' : 'badge-danger')
                 .text(status.toUpperCase());
        }
    });
}
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\status-pejabat-pta\resources\views/dashboard.blade.php ENDPATH**/ ?>