<?php $__env->startSection('content'); ?>
<div class="container">
    <h3>Edit Pejabat</h3>
    <form action="<?php echo e(route('employees.update', $employee->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
        <div class="form-group">
            <label>Nama <span class="text-danger">*</span></label>
            <input type="text" name="name" class="form-control" value="<?php echo e(old('name', $employee->name)); ?>" required>
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger small"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group">
            <label>Jabatan</label>
            <input type="text" name="position" class="form-control" value="<?php echo e(old('position', $employee->position)); ?>">
            <?php $__errorArgs = ['position'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger small"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group">
            <label>Kategori Jabatan <span class="text-danger">*</span></label>
            <select name="category" class="form-control" required>
                <option value="Pimpinan"        <?php echo e($employee->category=='Pimpinan' ? 'selected' : ''); ?>>Pimpinan</option>
                <option value="Hakim Tinggi"    <?php echo e($employee->category=='Hakim Tinggi' ? 'selected' : ''); ?>>Hakim Tinggi</option>
                <option value="Sekretaris dan Panitera" <?php echo e($employee->category=='Sekretaris dan Panitera' ? 'selected' : ''); ?>>Sekretaris dan Panitera</option>
                <option value="Kepala Bagian" <?php echo e($employee->category=='Kepala Bagian' ? 'selected' : ''); ?>>Kepala Bagian</option>
                <option value="Panitera Muda" <?php echo e($employee->category=='Panitera Muda' ? 'selected' : ''); ?>>Panitera Muda</option>
                <option value="Kepala Sub Bagian" <?php echo e($employee->category=='Kepala Sub Bagian' ? 'selected' : ''); ?>>Kepala Sub Bagian</option>
                <option value="Panitera Pengganti" <?php echo e($employee->category=='Panitera Pengganti' ? 'selected' : ''); ?>>Panitera Pengganti</option>
            </select>
            <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger small"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group">
            <label>Foto (biarkan kosong jika tidak diubah)</label>
            <input type="file" name="photo" class="form-control-file">
            <?php if($employee->photo): ?>
                <br><img src="/storage/<?php echo e($employee->photo); ?>" width="100">
            <?php endif; ?>
            <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger small"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <button class="btn btn-success">Update</button>
        <a href="<?php echo e(route('employees.index')); ?>" class="btn btn-secondary">Batal</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\status-pejabat-pta\resources\views/employees/edit.blade.php ENDPATH**/ ?>