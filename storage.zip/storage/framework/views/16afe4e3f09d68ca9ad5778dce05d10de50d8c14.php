<?php $__env->startSection('content'); ?>
<div class="container">
    <h3>Daftar Pejabat</h3>
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <a href="<?php echo e(route('employees.create')); ?>" class="btn btn-primary mb-3">+ Tambah Pejabat</a>
    <table class="table table-bordered table-striped">
        <thead class="thead-light">
            <tr>
                <th>Foto</th>
                <th>Nama</th>
                <th>Jabatan</th>
                <th>Kategori</th>
                <th>Dibuat</th>
                <th style="min-width: 130px">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php if($emp->photo): ?><img src="/storage/<?php echo e($emp->photo); ?>" width="60"><?php endif; ?></td>
                <td><?php echo e($emp->name); ?></td>
                <td><?php echo e($emp->position); ?></td>
                <td><?php echo e($emp->category); ?></td>
                <td><?php echo e($emp->created_at); ?></td>
                <td>
                    <a href="<?php echo e(route('employees.edit', $emp->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
                    <form action="<?php echo e(route('employees.destroy', $emp->id)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-sm btn-danger" onclick="return confirm('Yakin hapus?')">Hapus</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="6" class="text-center">Belum ada Pejabat</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\status-pejabat-pta\resources\views/employees/index.blade.php ENDPATH**/ ?>